-- Supabase starter schema for a free, non-monetary number-selection app.
-- No stake, wallet, deposits, withdrawals, or prize-payment tables are included.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.rounds (
  id uuid primary key default gen_random_uuid(),
  round_code text unique not null,
  status text not null default 'open' check (status in ('open','closed','published')),
  opens_at timestamptz,
  closes_at timestamptz,
  winning_number smallint check (winning_number between 1 and 10),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  check ((status <> 'published') or (winning_number is not null and published_at is not null))
);

create table if not exists public.number_picks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  round_id uuid not null references public.rounds(id) on delete cascade,
  chosen_numbers smallint[] not null,
  created_at timestamptz not null default now(),
  unique (user_id, round_id),
  check (cardinality(chosen_numbers) between 1 and 10),
  check (chosen_numbers <@ array[1,2,3,4,5,6,7,8,9,10]::smallint[])
);

alter table public.profiles enable row level security;
alter table public.rounds enable row level security;
alter table public.number_picks enable row level security;

create policy "profile owner can read own profile"
on public.profiles for select to authenticated using (auth.uid() = id);
create policy "profile owner can insert own profile"
on public.profiles for insert to authenticated with check (auth.uid() = id);
create policy "profile owner can update own profile"
on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

create policy "authenticated users can view rounds"
on public.rounds for select to authenticated using (true);

create policy "users can read own picks"
on public.number_picks for select to authenticated using (auth.uid() = user_id);
create policy "users can create own picks for open rounds"
on public.number_picks for insert to authenticated
with check (
  auth.uid() = user_id
  and exists (select 1 from public.rounds r where r.id = round_id and r.status = 'open')
);

-- IMPORTANT:
-- Do not allow public users to update rounds or publish results.
-- Manage result publication using a trusted server-side admin function/service role,
-- never expose the Supabase service_role key in browser code.
-- Before any money/prize features, obtain legal and payment-provider approval and
-- conduct a separate security review.
