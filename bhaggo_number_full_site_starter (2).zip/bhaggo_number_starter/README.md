# ভাগ্য সংখ্যা — starter project

## এই প্যাকেজে কী আছে
- `public/index.html`: বাংলা মোবাইল-উপযোগী frontend demo
- `supabase/schema.sql`: Supabase-এর জন্য প্রাথমিক database schema এবং Row Level Security policies

## এখন যা কাজ করে
- ১–১০ থেকে এক বা একাধিক সংখ্যা বেছে নেওয়া
- ডেমো নির্বাচনের বার্তা
- ফলাফলের নমুনা টেবিল

## এখনো যা কাজ করে না
- বাস্তব নিবন্ধন/লগইন
- সার্ভারে নির্বাচন সংরক্ষণ
- আসল রাউন্ড/ফলাফল প্রকাশ
- বিকাশ/নগদ পেমেন্ট
- টাকা জমা, উত্তোলন বা পুরস্কার প্রদান

## নিরাপদভাবে পরবর্তী ধাপ
1. Supabase-এ নতুন project তৈরি করুন।
2. SQL Editor-এ `supabase/schema.sql` পর্যালোচনা করে চালান।
3. Authentication-এ email verification চালু করুন।
4. frontend-এ Supabase client যুক্ত করার আগে প্রকল্পের URL ও anon/publishable key ব্যবহার করুন; `service_role` key কখনো browser-এ দেবেন না।
5. ফলাফল প্রকাশ কেবল server-side admin action দিয়ে করুন; সাধারণ ব্যবহারকারীকে `rounds` টেবিল পরিবর্তনের অনুমতি দেবেন না।
6. ব্যাকআপ, লগিং, গোপনীয়তা নীতি ও নিরাপত্তা পরীক্ষা করুন।

## বিকাশ ও নগদ
এই starter-এ কোনো পেমেন্ট integration নেই। বিকাশ/নগদের অনুমোদিত merchant/gateway onboarding, API credentials, webhook signature verification এবং server-side transaction verification ছাড়া পেমেন্ট চালু করবেন না। PIN/OTP সংগ্রহ করবেন না। টাকা দিয়ে ভাগ্যনির্ভর নির্বাচন ও পুরস্কারের মডেল চালুর আগে বাংলাদেশের প্রযোজ্য আইন ও প্রয়োজনীয় অনুমোদন যাচাই করুন। অনুমোদন ছাড়া বাস্তব বাজি/পুরস্কার ব্যবস্থা চালু করবেন না।

## চালানোর সহজ উপায়
`public/index.html` ফাইলটি ব্রাউজারে খুললে demo দেখা যাবে। এটি static demo; online deployment বা real account তৈরি করে না।
